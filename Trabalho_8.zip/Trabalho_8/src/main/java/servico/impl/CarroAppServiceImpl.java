package servico.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import anotacoes.Perfil;
import dao.CarroDAO;
import dao.MotoristaDAO;
import excecao.CarroJaTemViagensException;
import excecao.CarroNaoEncontradoException;
import excecao.ObjetoNaoEncontradoException;
import excecao.MotoristaNaoEncontradoException;
import modelo.Carro;
import modelo.Motorista;
import service.CarroAppService;

public class CarroAppServiceImpl implements CarroAppService {
	@Autowired
	private CarroDAO carroDAO;
	@Autowired
	private MotoristaDAO motoristaDAO;

	@Transactional
	@Perfil(nomes={"admin"})
	public long inclui(Carro umCarro) throws MotoristaNaoEncontradoException {

		try {
			// NENHUMA VALIDA��O EST� SENDO REALIZADA AQUI!!!

			Motorista umMotorista = umCarro.getMotorista();

			try {
				motoristaDAO.recuperaUmMotoristaComLock(umMotorista.getId());
			} catch (ObjetoNaoEncontradoException e) {
				throw new MotoristaNaoEncontradoException("Personagem n�o encontado");
			}

			long numero = carroDAO.inclui(umCarro);

			return numero;
		} catch (MotoristaNaoEncontradoException e) {

			throw e;
		}
	}

	@Transactional
	public void altera(Carro umCarro) throws CarroNaoEncontradoException {
		try {
			carroDAO.altera(umCarro);

		} catch (ObjetoNaoEncontradoException e) {

			throw new CarroNaoEncontradoException("Carro n�o encontrado");
		}
	}

	@Transactional
	public void exclui(long numero) throws CarroNaoEncontradoException {
		try {
			Carro carro = carroDAO.recuperaUmCarroEViagens(numero);
			
			if(carro.getViagens().size() > 0)
			{	throw new CarroJaTemViagensException("Este carro possui viagens e n�o pode ser removido!");
			}

			carroDAO.exclui(numero);
		} catch (ObjetoNaoEncontradoException e) {
			throw new CarroNaoEncontradoException("Carro n�o encontrado");
		}
	}

	public Carro recuperaUmCarro(long numero) throws CarroNaoEncontradoException {
		try {
			Carro umCarro = carroDAO.recuperaUmCarro(numero);

			return umCarro;
		} catch (ObjetoNaoEncontradoException e) {
			throw new CarroNaoEncontradoException("Carro n�o encontrado");
		}
	}

	public Carro recuperaUmCarroEViagens(long numero) throws CarroNaoEncontradoException {
		try {
			return carroDAO.recuperaUmCarroEViagens(numero);
		} catch (ObjetoNaoEncontradoException e) {
			throw new CarroNaoEncontradoException("Carro n�o encontrado");
		}
	}

	public List<Carro> recuperaCarrosEViagens() {

		return carroDAO.recuperaCarrosEViagens();
	}
}